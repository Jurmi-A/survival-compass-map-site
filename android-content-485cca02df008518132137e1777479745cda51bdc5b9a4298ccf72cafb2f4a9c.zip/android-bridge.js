(() => {
  'use strict';
  // This script is packaged only in the APK and runs before the shared map code.
  window.IS_STANDALONE = true;
  window.DURU_ANDROID = true;
  const contentSession=typeof DuruNative.sessionToken==='function'?DuruNative.sessionToken():'';
  const bootErrors=[];let contentState=null,applying=false;
  window.addEventListener('error',e=>{if(e.target instanceof HTMLScriptElement)bootErrors.push(e.target.src);},true);
  window.__duruContentUpdate = data => {
    contentState=data;
    const info=document.getElementById('contentUpdateInfo'),check=document.getElementById('checkContentUpdate'),apply=document.getElementById('applyContentUpdate');
    if(!info)return;
    const applyFailed=applying&&data.status==='error';
    applying=false;
    const ready=!!data.pendingVersion&&!['checking','downloading'].includes(data.status);
    const needsApk=data.status==='apk';
    const pct=data.totalBytes>0?Math.min(100,Math.floor(100*data.doneBytes/data.totalBytes)):0;
    const defer=data.manualApply?'버튼을 누를 때까지 지금 지도를 쓸 수 있습니다.':'앱을 완전히 닫고 다시 열면 자동으로 적용됩니다.';
    const messages={
      checking:'새 자료를 확인하고 있습니다.',
      current:'현재 자료를 확인했습니다.',
      downloading:`새 자료를 받는 중 · ${pct}% · 지금 지도는 계속 사용할 수 있습니다.`,
      ready:`자료 ${data.pendingVersion} 준비 완료. ${defer} 인터넷 없이도 적용할 수 있습니다.`,
      error:applyFailed?'새 자료를 적용하지 못했습니다. 저장된 지도는 계속 사용할 수 있습니다.':'새 자료를 받지 못했습니다. 저장된 지도는 계속 사용할 수 있습니다.',
      apk:'이 업데이트에는 새 설치 파일이 필요합니다.'
    };
    document.getElementById('autoContentUpdate').checked=data.auto!==false;
    info.textContent=`앱 ${data.baseVersion} 베타 · 자료 ${data.version}\n`+(messages[data.status]||'');
    check.disabled=['checking','downloading'].includes(data.status);
    apply.hidden=!ready;
    apply.disabled=false;
    document.getElementById('contentApkLink').hidden=!needsApk;
    if(ready||needsApk){
      window.DURU_UPDATE?.show({
        type:'OFFLINE_INSTALL_READY',reason:'update',native:true,
        version:ready?data.pendingVersion:'apk',
        title:ready?`새 지도 자료 ${data.pendingVersion} 준비됨`:'새 앱 버전이 있습니다',
        detail:ready?defer:'새 설치 파일을 받아 기존 앱 위에 설치하세요.',
        actionLabel:ready?'업데이트':'설치 파일 받기'
      });
      document.getElementById('updateReload').disabled=false;
    }else window.DURU_UPDATE?.hide();
    if(data.status==='error'&&data.manual)window.DURU?.toast(messages.error);
  };
  function applyContent(){
    if(applying||!contentState?.pendingVersion||['checking','downloading'].includes(contentState.status))return;
    if(!confirm('새 자료를 적용하고 지도를 다시 엽니다. 저장한 장소와 계획은 유지됩니다. 표시 중인 도보 경로는 다시 계산해야 합니다.'))return;
    applying=true;
    for(const id of ['applyContentUpdate','checkContentUpdate','updateReload'])document.getElementById(id).disabled=true;
    document.getElementById('contentUpdateInfo').textContent='새 지도 자료를 적용하는 중입니다…';
    document.getElementById('updateDetail').textContent='새 지도 자료를 적용하는 중입니다…';
    DuruNative.applyContentUpdate();
  }
  let sequence = 0;
  const positions = new Map(), backups = new Map();
  const shares = new Map();
  window.DURU_MONOTONIC = () => Number(DuruNative.monotonicMillis());
  let compassSequence=0,compassListener=null;
  window.DURU_START_COMPASS = listener => {
    const id=++compassSequence;compassListener={id,listener};
    try{DuruNative.startCompass(id);}catch(_){listener({status:'unavailable',heading:null});}
    return ()=>{if(compassListener?.id!==id)return;compassListener=null;try{DuruNative.stopCompass(id);}catch(_){};};
  };
  window.__duruCompass = (id,reading) => {if(compassListener?.id===id)compassListener.listener(reading);};
  window.DURU_SHARE_TEXT = text => new Promise((resolve,reject) => {
    const id=++sequence;
    const timer=setTimeout(()=>{shares.delete(id);reject(Error('공유 화면의 응답을 확인하지 못했습니다. 상대 수신 여부를 확인하세요.'));},15000);
    shares.set(id,{resolve,reject,timer});
    try { DuruNative.shareText(id,text); } catch (_) { window.__duruShareResult(id,false,'공유 화면을 열지 못했습니다.'); }
  });
  window.__duruShareResult = (id,ok,message) => {
    const request=shares.get(id);if(!request)return;shares.delete(id);clearTimeout(request.timer);
    ok?request.resolve():request.reject(Error(message));
  };
  Object.defineProperty(navigator, 'geolocation', {value: {
    getCurrentPosition(success, failure) {
      const id = ++sequence;
      const timer = setTimeout(() => {
        if (!positions.delete(id)) return;
        try { DuruNative.cancelLocation(id); } catch (_) {}
        failure?.({code:3,message:'위치 확인 응답이 없습니다. 권한과 GPS 설정을 확인한 뒤 다시 시도하세요.'});
      }, 180000);
      positions.set(id, {success, failure, timer});
      try { DuruNative.requestLocation(id); }
      catch (_) { window.__duruPosition(id, null, {code:2,message:'GPS 연결에 실패했습니다. 앱을 다시 열거나 수동 기준점을 이용하세요.'}); }
    }
  }});
  window.__duruPosition = (id, position, error) => {
    const request = positions.get(id);
    if (!request) return;
    clearTimeout(request.timer);
    positions.delete(id);
    if (error) request.failure?.(error); else request.success(position);
  };
  window.DURU_SAVE_BACKUP = (name, text) => new Promise(resolve => {
    if (new TextEncoder().encode(text).length > 2000000) { window.DURU?.toast('백업 파일이 너무 큽니다.'); resolve(false); return; }
    const id = ++sequence;
    backups.set(id, resolve);
    DuruNative.saveBackup(id, name, text);
  });
  window.__duruBackup = (id, ok, message) => {
    const resolve = backups.get(id);
    if (!resolve) return;
    backups.delete(id);
    window.DURU?.toast(message);
    resolve(ok);
  };
  window.__duruRecoveredBackup = (ok, name, message) => {
    if (ok && name?.replace('두루지도','생존나침반') === '생존나침반-내장소.json') {
      try { localStorage.setItem('duru-pins-last-backup', String(Date.now())); } catch (_) {}
    }
    window.DURU?.toast(message);
  };
  window.__duruBack = () => {
    const modal = document.querySelector('dialog[open]');
    if (modal) { modal.close(); return true; }
    const panel = document.getElementById('bottomPanel');
    if (panel && !panel.classList.contains('hidden')) { document.getElementById('closePanel').click(); return true; }
    const search = document.getElementById('search');
    if (search?.value) { document.getElementById('clearSearch').click(); search.blur(); return true; }
    return false;
  };
  document.addEventListener('DOMContentLoaded', () => {
    const steps = document.querySelectorAll('#helpDialog .step');
    const text = [
      ['설치하면 지도 준비 완료', '전국 지도와 앱 화면이 설치 파일에 포함되어 있습니다. 첫 실행부터 인터넷 연결과 로그인이 필요 없습니다.'],
      ['앱 목록에서 생존나침반 실행', '홈 화면 또는 앱 목록의 생존나침반 아이콘으로 여세요. 별도 크롬 창을 열 필요가 없습니다.'],
      ['비행기 모드로 미리 확인', '앱을 완전히 닫고 비행기 모드에서 다시 열어 지도·검색·재난 대비를 확인하세요. GPS는 위치 권한과 기기의 위치 설정을 켜야 하며 야외에서도 수신에 시간이 걸릴 수 있습니다.']
    ];
    steps.forEach((step, i) => {
      step.querySelector('h3').textContent = text[i][0];
      step.querySelector('p').textContent = text[i][1];
    });
    document.getElementById('downloadMap').hidden = true;
    document.getElementById('cacheMap').hidden = true;
    document.querySelector('#helpDialog .info-note p:last-child').textContent = '앱을 삭제하거나 앱 데이터를 지우면 내 장소와 계획이 삭제됩니다. 아래의 백업 기능으로 파일을 따로 보관하세요. 웹 버전에서 쓰던 장소·계획은 JSON 백업을 가져와야 합니다.';
    document.getElementById('connectionInfo').textContent = '처음부터 지도 자료가 포함되어 있으며, 인터넷 연결 시 공개 배포 서버에서 서명된 새 자료를 받아 앱 내부에 저장합니다. 검색어·GPS·장소·계획을 서버로 보내지 않습니다. 서버에는 접속에 필요한 IP 등 일반 연결 정보가 전달될 수 있습니다. 자료 출처 링크는 선택했을 때 별도 브라우저로 엽니다.';
    const update=document.createElement('section');update.className='info-note';update.id='nativeContentUpdate';
    update.innerHTML='<h3>앱 안에서 업데이트</h3><p id="contentUpdateInfo" style="white-space:pre-line">저장한 자료 버전을 확인합니다.</p><label><input id="autoContentUpdate" type="checkbox" checked> 앱을 열 때 자동으로 새 자료 확인</label><p class="small-note">끄면 다음 확인부터 수동으로만 연결합니다. 이미 시작한 다운로드는 마무리될 수 있습니다.</p><button id="checkContentUpdate" class="secondary-button wide">새 자료 확인</button><button id="applyContentUpdate" class="primary-button wide" hidden>새 자료 적용</button><a id="contentApkLink" class="secondary-button wide" href="https://jurmi-a.github.io/survival-compass-map-site/생존나침반-베타.apk" hidden>새 설치파일 받기</a><p class="small-note">연결되면 새 자료를 자동으로 받습니다. 지도·화면·행동요령은 재설치 없이 갱신되며, 기기 기능 변경은 새 APK가 필요할 수 있습니다. 통신이 끊기면 마지막으로 확인된 지도를 사용합니다.</p>';
    document.getElementById('offlineState').after(update);
    document.getElementById('checkContentUpdate').onclick=()=>DuruNative.checkContentUpdate();
    document.getElementById('autoContentUpdate').onchange=e=>DuruNative.autoContentUpdates(e.target.checked);
    document.getElementById('applyContentUpdate').onclick=applyContent;
    document.getElementById('updateReload').onclick=()=>{
      if(contentState?.status==='apk'&&!contentState.pendingVersion)document.getElementById('contentApkLink').click();
      else applyContent();
    };
    if(contentState)window.__duruContentUpdate(contentState);
    const notes = document.querySelectorAll('#emergency-plan .small-note');
    if (notes.length) notes[notes.length - 1].textContent = '장소·메모는 ‘오프라인 → 내 장소 백업’에서 별도로 보관하세요. 앱을 삭제하거나 앱 데이터를 지우면 계획도 사라집니다.';
    DuruNative.ready();
    setTimeout(()=>{if(!bootErrors.length&&window.DURU?.state.roads>0&&window.DURU_PREP&&window.DURU_SHARING&&window.DURU_ROUTING&&document.getElementById('compassDialog')){try{DuruNative.contentHealthy(contentSession);}catch(_){}}},2000);
  });
})();

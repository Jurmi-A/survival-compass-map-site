// Replaced by walk-core.js and walk-*.js (nationwide walking data). Kept for older app versions.
